

class AsyncAI():
	"""docstring for AsyncAI"""
	def __init__(self):
		super(AsyncAI, self).__init__()
		
	def get(self):
		return "Salom"


